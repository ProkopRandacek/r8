This is zipped because I dont want GLAD's 20k lines to randomly appear in my github statistics
